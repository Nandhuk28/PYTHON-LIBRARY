# Topic 1: Opening and Exploring the Data

# Task 1: Import Python Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# Task 2: Load the CSV File
df = pd.read_csv("Retail_Sales_Easy_Project.csv")

print(df.head())


# Task 3: Load the Excel File
df_excel = pd.read_excel("Retail_Sales_Easy_Project.xlsx", sheet_name="SalesData")

print(df_excel.tail())


# Task 4: View Random Rows
print(df.sample(6))


# Topic 2: Checking Data Quality and Structure


# Task 5: Check Data Types and Missing Values
print(df.columns)
print(df.dtypes)
print(df.isnull().sum())


# Task 6: Summary of Numbers
print(df.describe())


# Task 7: Check Table Size
print("Number of rows:", df.shape[0])
print("Number of columns:", df.shape[1])


# Task 8: Count Non-Empty Values
print(df.count())


# Topic 3: Using NumPy for Basic Calculations


# Task 9: Convert Revenue Column to an Array

revenue = df["Total_Revenue"].to_numpy()

print(revenue)
print(revenue.dtype)
print(len(revenue))


# Task 10: Create a 2D Array

price_quantity = df[["Unit_Price", "Quantity"]].to_numpy()

print(price_quantity)
print(price_quantity.shape)


# Task 11: Calculate Grand Total Revenue

total_revenue = np.sum(revenue)

print("Grand Total Revenue:", total_revenue)


# Task 12: Find Mean and Median Revenue

mean_revenue = np.mean(revenue)
median_revenue = np.median(revenue)

print("Mean Revenue:", mean_revenue)
print("Median Revenue:", median_revenue)

# Topic 4: Finding Extremes and Spread


# Task 13: Calculate Spread

std_revenue = np.std(revenue)
var_revenue = np.var(revenue)

print("Standard Deviation:", std_revenue)
print("Variance:", var_revenue)


# Task 14: Find Lowest and Highest Sales

lowest_sale = np.min(revenue)
highest_sale = np.max(revenue)

print("Lowest Sale:", lowest_sale)
print("Highest Sale:", highest_sale)


# Task 15: Find Row of Best and Worst Sale

best_row = np.argmax(revenue)
worst_row = np.argmin(revenue)

print("Index of Highest Sale:", best_row)
print("Index of Lowest Sale:", worst_row)


# Task 16: Calculate Running Total

running_total = np.cumsum(revenue)

print(running_total)


# Topic 5: Selecting and Slicing Rows


# Task 17: Select Rows by Position

print(df.iloc[:10])


# Task 18: Select Specific Rows and Columns

print(df.loc[100:120, ["Product_Name", "Total_Revenue", "Store_City"]])


# Topic 6: Filtering Records


# Task 19: Filter by Category

electronics = df[df["Category"] == "Electronics"]

print(electronics)


# Task 20: Filter with Multiple Conditions

result = df[(df["Quantity"] >= 5) & (df["Payment_Method"] == "UPI")]

print(result)


# Task 21: Filter by Selected Cities

selected_cities = df[df["Store_City"].isin(["Chennai", "Coimbatore", "Madurai"])]

print(selected_cities)


# Task 22: Filter Sales Outside Chennai

outside_chennai = df[df["Store_City"] != "Chennai"]

print(outside_chennai)


# Task 23: Tag High Value Orders

def check_value(revenue):
    if revenue > 5000:
        return "High Value"
    else:
        return "Standard"

df["Order_Value"] = df["Total_Revenue"].apply(check_value)

print(df[["Total_Revenue", "Order_Value"]])


# Topic 7: Creating New Columns and Sorting


# Task 24: Calculate Net Profit

df["Net_Profit"] = df["Total_Revenue"] - df["Cost_Price"]

print(df[["Total_Revenue", "Cost_Price", "Net_Profit"]])


# Task 25: Calculate Profit Margin

df["Profit_Margin_Pct"] = (df["Net_Profit"] / df["Total_Revenue"]) * 100

print(df[["Net_Profit", "Total_Revenue", "Profit_Margin_Pct"]])


# Task 26: Sort by Revenue

sorted_revenue = df.sort_values("Total_Revenue", ascending=False)

print(sorted_revenue)


# Task 27: Sort by Category and Profit

sorted_data = df.sort_values(
    ["Category", "Net_Profit"],
    ascending=[True, False]
)

print(sorted_data)

# Topic 8: Counting and Grouping


# Task 28: Count Unique Items

category_count = df["Category"].nunique()
product_count = df["Product_Name"].nunique()

print("Number of unique categories:", category_count)
print("Number of unique products:", product_count)


# Task 29: Total Sales by Category

category_sales = df.groupby("Category").agg(
    Total_Revenue=("Total_Revenue", "sum"),
    Average_Revenue=("Total_Revenue", "mean"),
    Number_of_Sales=("Transaction_ID", "count")
)

print(category_sales)


# Topic 9: Charts and Visualizations


# Task 30: Line Chart of Sales Over Time

df["Date"] = pd.to_datetime(df["Date"])

daily_sales = df.groupby("Date")["Total_Revenue"].sum()

plt.plot(daily_sales.index, daily_sales.values, marker="o")

plt.show()


# Task 31: Add Labels and Title

plt.plot(daily_sales.index, daily_sales.values, marker="o")

plt.xlabel("Date")
plt.ylabel("Revenue in INR")
plt.title("Sales Revenue Over Time")

plt.show()


# Task 32: Bar Chart of City Sales

city_sales = df.groupby("Store_City")["Total_Revenue"].sum()

plt.bar(city_sales.index, city_sales.values)

plt.xlabel("Store City")
plt.ylabel("Total Revenue")
plt.title("Total Sales by City")

plt.show()


# Task 33: Pie Chart of Category Sales

category_revenue = df.groupby("Category")["Total_Revenue"].sum()

explode = [0.1 if value == category_revenue.max() else 0
           for value in category_revenue]

plt.pie(
    category_revenue.values,
    labels=category_revenue.index,
    autopct="%1.1f%%",
    explode=explode
)

plt.title("Sales Share by Category")

plt.show()


# Task 34: Scatter Plot of Price vs Quantity

categories = df["Category"].unique()

for category in categories:
    data = df[df["Category"] == category]
    plt.scatter(data["Unit_Price"], data["Quantity"], label=category)

plt.xlabel("Unit Price")
plt.ylabel("Quantity")
plt.title("Unit Price vs Quantity")
plt.legend()

plt.show()


# Task 35: Bar Chart of Profit by Payment Method

payment_profit = df.groupby("Payment_Method")["Net_Profit"].mean()

plt.bar(payment_profit.index, payment_profit.values)

plt.xlabel("Payment Method")
plt.ylabel("Average Net Profit")
plt.title("Average Net Profit by Payment Method")

plt.savefig("profit_by_payment_method.png")

plt.show()
