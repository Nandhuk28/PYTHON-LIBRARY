import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# Load the dataset
df = pd.read_csv("Fintech_Loan_Risk_Expert_Project.csv")

# Display first 5 rows
print(df.head())

# Display dataset information
print("\nDataset Information:")
df.info(memory_usage="deep")

# Display total memory usage
print("\nTotal Memory Usage:")
print(df.memory_usage(deep=True).sum(), "bytes")


# topic 2

# Task 3
df['Age'] = df['Age'].astype(int)
df['Loan_Term_Months'] = df['Loan_Term_Months'].astype(int)
df['Debt_to_Income_Ratio'] = df['Debt_to_Income_Ratio'].astype(float)

print(df[['Age', 'Loan_Term_Months', 'Debt_to_Income_Ratio']].dtypes)

# Task 4
print("Missing values:")
print(df.isnull().sum())

print("Blank values:")
print((df == '').sum())

print("Infinite values:")
print(np.isinf(df.select_dtypes(include=np.number)).sum())

# Task 5
invalid_income = df[df['Annual_Income'] <= 0]

invalid_credit_score = df[
    (df['Credit_Score'] < 300) |
    (df['Credit_Score'] > 850)
]

print("Invalid income records:", len(invalid_income))
print("Invalid credit score records:", len(invalid_credit_score))

# Task 6
print("25th percentile:", df['Loan_Amount'].quantile(0.25))
print("50th percentile:", df['Loan_Amount'].quantile(0.50))
print("75th percentile:", df['Loan_Amount'].quantile(0.75))
print("90th percentile:", df['Loan_Amount'].quantile(0.90))

#topic 3


# Task 7
income = df['Annual_Income'].dropna().to_numpy()

total_income = 0

for value in income:
    total_income = total_income + value

manual_mean = total_income / len(income)

python_mean = df['Annual_Income'].mean()

print("Task 7")
print("Manual Mean:", manual_mean)
print("Python Mean:", python_mean)


# Task 8
squared_difference_sum = 0

for value in income:
    difference = value - manual_mean
    squared_difference = difference ** 2
    squared_difference_sum = squared_difference_sum + squared_difference

manual_variance = squared_difference_sum / len(income)

python_variance = df['Annual_Income'].var(ddof=0)

print("\nTask 8")
print("Manual Variance:", manual_variance)
print("Python Variance:", python_variance)


# Task 9
manual_standard_deviation = manual_variance ** 0.5

python_standard_deviation = df['Annual_Income'].std(ddof=0)

print("\nTask 9")
print("Manual Standard Deviation:", manual_standard_deviation)
print("Python Standard Deviation:", python_standard_deviation)


# Task 10
credit_score = df['Credit_Score'].dropna()

population_std = credit_score.std(ddof=0)
sample_std = credit_score.std(ddof=1)

difference = sample_std - population_std

print("\nTask 10")
print("Population Standard Deviation:", population_std)
print("Sample Standard Deviation:", sample_std)
print("Difference:", difference)


#topic 4

# Task 11

credit_score = df['Credit_Score'].dropna().sort_values().to_numpy()

n = len(credit_score)

if n % 2 == 1:
    manual_median = credit_score[n // 2]
else:
    middle1 = credit_score[(n // 2) - 1]
    middle2 = credit_score[n // 2]
    manual_median = (middle1 + middle2) / 2

python_median = df['Credit_Score'].median()

print("Task 11")
print("Manual Median:", manual_median)
print("Python Median:", python_median)


# Task 12

income = df['Annual_Income'].dropna()

standard_deviation = income.std(ddof=1)
sample_size = len(income)

standard_error = standard_deviation / np.sqrt(sample_size)

print("\nTask 12")
print("Standard Error:", standard_error)


# Task 13

debt_ratio = df['Debt_to_Income_Ratio']

q25 = debt_ratio.quantile(0.25)
q75 = debt_ratio.quantile(0.75)

iqr = q75 - q25

lower_limit = q25 - 1.5 * iqr
upper_limit = q75 + 1.5 * iqr

extreme_borrowers = df[
    (debt_ratio < lower_limit) |
    (debt_ratio > upper_limit)
]

print("\nTask 13")
print("25th Percentile:", q25)
print("75th Percentile:", q75)
print("IQR:", iqr)
print("Lower Limit:", lower_limit)
print("Upper Limit:", upper_limit)

print("\nExtreme Borrowers:")
print(extreme_borrowers)

#topic 5

# Task 14

loan_amount = df['Loan_Amount'].to_numpy()
interest_rate = df['Interest_Rate'].to_numpy()
loan_term = df['Loan_Term_Months'].to_numpy()

print("Task 14")
print("Loan Amount:", loan_amount[:5])
print("Interest Rate:", interest_rate[:5])
print("Loan Term:", loan_term[:5])


# Task 15

monthly_interest = (interest_rate / 100) / 12

print("\nTask 15")
print("Monthly Interest:", monthly_interest[:5])


# Task 16

emi = loan_amount * monthly_interest * (1 + monthly_interest) ** loan_term
emi = emi / ((1 + monthly_interest) ** loan_term - 1)

print("\nTask 16")
print("Calculated EMI:", emi[:5])


# Task 17

dataset_emi = df['Monthly_EMI'].to_numpy()

difference = emi - dataset_emi

print("\nTask 17")
print("Dataset EMI:", dataset_emi[:5])
print("Calculated EMI:", emi[:5])
print("Difference:", difference[:5])

print("Maximum Difference:", np.max(np.abs(difference)))

#topic 6

# Task 18

loan_amount = df['Loan_Amount'].to_numpy()
annual_income = df['Annual_Income'].to_numpy()
monthly_emi = df['Monthly_EMI'].to_numpy()

loan_matrix = np.column_stack((loan_amount, annual_income, monthly_emi))

print("Task 18")
print("2D Matrix:")
print(loan_matrix)

print("\nMatrix Shape:")
print(loan_matrix.shape)

column_average = np.mean(loan_matrix, axis=0)

print("\nAverage Loan Amount:", column_average[0])
print("Average Annual Income:", column_average[1])
print("Average Monthly EMI:", column_average[2])


# Task 19

debt_burden = (monthly_emi * 12) / annual_income

print("\nTask 19")
print("Debt Burden:")
print(debt_burden)


# Task 20

safest_row = np.argmin(debt_burden)
riskiest_row = np.argmax(debt_burden)

print("\nTask 20")
print("Safest Borrower Row Number:", safest_row)
print("Safest Debt Burden:", debt_burden[safest_row])

print("Riskiest Borrower Row Number:", riskiest_row)
print("Riskiest Debt Burden:", debt_burden[riskiest_row])

#topic 7

# Task 21

conditions = [
    (df['Credit_Score'] < 600) | (df['Debt_to_Income_Ratio'] > 0.45),
    (df['Credit_Score'] >= 750)
]

choices = [
    'High Risk',
    'Low Risk'
]

df['Risk_Category'] = np.select(
    conditions,
    choices,
    default='Medium Risk'
)

print("Task 21")
print(df[['Credit_Score', 'Debt_to_Income_Ratio', 'Risk_Category']].head())


# Task 22

df['Loan_Size'] = pd.cut(
    df['Loan_Amount'],
    bins=4,
    labels=['Small', 'Medium', 'Large', 'Very Large']
)

print("\nTask 22")
print(df[['Loan_Amount', 'Loan_Size']].head())


# Task 23

default_count = pd.crosstab(
    df['Risk_Category'],
    df['Loan_Status']
)

print("\nTask 23")
print(default_count)


# Task 24

default_data = df[df['Loan_Status'] == 'Default']

default_percentage = (
    default_data.groupby('Loan_Purpose').size()
    / df.groupby('Loan_Purpose').size()
    * 100
)

print("\nTask 24")
print(default_percentage)

#topic 8

# Task 25

high_risk_defaulters = df[
    (df['Risk_Category'] == 'High Risk') &
    (df['Loan_Status'] == 'Default')
]

print("Task 25")
print(high_risk_defaulters)


# Task 26

active_loans = df[df['Loan_Status'] == 'Active']

active_loans = active_loans.sort_values(
    by='Interest_Rate',
    ascending=False
)

active_loans['Running_Loan_Amount'] = active_loans['Loan_Amount'].cumsum()

print("\nTask 26")
print(active_loans[
    ['Loan_Amount', 'Interest_Rate', 'Running_Loan_Amount']
])


# Task 27

renter_data = df[df['Home_Ownership'] == 'Rent']
owner_data = df[df['Home_Ownership'] == 'Own']

renter_default_rate = (
    (renter_data['Loan_Status'] == 'Default').sum()
    / len(renter_data)
) * 100

owner_default_rate = (
    (owner_data['Loan_Status'] == 'Default').sum()
    / len(owner_data)
) * 100

print("\nTask 27")
print("Renter Default Rate:", renter_default_rate)
print("Owner Default Rate:", owner_default_rate)

#for check unique values
print(df['Loan_Status'].unique())
print(df['Home_Ownership'].unique())

#topic 9



# Task 28
# Correlation Grid Chart

correlation = df[
    ['Annual_Income', 'Credit_Score', 'Loan_Amount', 'Monthly_EMI']
].corr()

plt.figure(figsize=(8, 6))
sns.heatmap(correlation, annot=True, cmap='coolwarm')
plt.title('Correlation Between Loan Features')
plt.show()


# Task 29
# Histogram of Credit Scores

plt.figure(figsize=(8, 5))

plt.hist(df['Credit_Score'], bins=20)

mean_score = df['Credit_Score'].mean()
median_score = df['Credit_Score'].median()

plt.axvline(mean_score, linestyle='--', label='Mean')
plt.axvline(median_score, linestyle='-', label='Median')

plt.xlabel('Credit Score')
plt.ylabel('Number of Borrowers')
plt.title('Credit Score Distribution')
plt.legend()
plt.show()


# Task 30
# Interest Rates Across Risk Levels

plt.figure(figsize=(8, 5))

sns.boxplot(
    x='Risk_Category',
    y='Interest_Rate',
    data=df
)

plt.xlabel('Risk Category')
plt.ylabel('Interest Rate')
plt.title('Interest Rates Across Risk Levels')
plt.show()


# Task 31
# Income vs Loan Amount

plt.figure(figsize=(8, 5))

sns.scatterplot(
    data=df,
    x='Annual_Income',
    y='Loan_Amount',
    hue='Loan_Status'
)

plt.xlabel('Annual Income')
plt.ylabel('Loan Amount')
plt.title('Income vs Loan Amount')
plt.show()


# Task 32
# Debt Ratio Density Curves

plt.figure(figsize=(8, 5))

defaulted = df[df['Loan_Status'] == 'Default']
paid = df[df['Loan_Status'] == 'Fully Paid']

sns.kdeplot(
    defaulted['Debt_to_Income_Ratio'],
    label='Default'
)

sns.kdeplot(
    paid['Debt_to_Income_Ratio'],
    label='Fully Paid'
)

plt.xlabel('Debt to Income Ratio')
plt.ylabel('Density')
plt.title('Debt Ratio Distribution by Loan Status')
plt.legend()
plt.show()


# Task 33
# Average Unpaid Loan Amount by Purpose

df['Unpaid_Amount'] = np.where(
    df['Loan_Status'] == 'Default',
    df['Loan_Amount'],
    0
)

loss_by_purpose = (
    df.groupby('Loan_Purpose')['Unpaid_Amount']
    .mean()
    .sort_values()
)

plt.figure(figsize=(8, 5))

loss_by_purpose.plot(kind='barh')

plt.xlabel('Average Unpaid Loan Amount')
plt.ylabel('Loan Purpose')
plt.title('Average Unpaid Loan Amount by Purpose')
plt.show()


# Task 34
# 4-Chart Risk Dashboard

fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Credit Score Histogram
axes[0, 0].hist(df['Credit_Score'], bins=20)
axes[0, 0].set_title('Credit Score Histogram')
axes[0, 0].set_xlabel('Credit Score')
axes[0, 0].set_ylabel('Borrowers')

# Debt Ratio Boxplot
sns.boxplot(
    y=df['Debt_to_Income_Ratio'],
    ax=axes[0, 1]
)
axes[0, 1].set_title('Debt Ratio Boxplot')

# Risk Level Pie Chart
risk_counts = df['Risk_Category'].value_counts()

axes[1, 0].pie(
    risk_counts,
    labels=risk_counts.index,
    autopct='%1.1f%%'
)

axes[1, 0].set_title('Risk Level Distribution')

# Income vs Loan Scatter
sns.scatterplot(
    data=df,
    x='Annual_Income',
    y='Loan_Amount',
    hue='Loan_Status',
    ax=axes[1, 1]
)

axes[1, 1].set_title('Income vs Loan Amount')

plt.tight_layout()
plt.show()


# Task 35
# Save Clean Data

df.to_excel(
    'Fintech_Loan_Risk_Final.xlsx',
    index=False
)

df.to_csv(
    'Fintech_Loan_Risk_Final.csv',
    index=False
)

print("Final Excel file saved successfully.")
print("Final CSV file saved successfully.")


# Three Key Findings

default_rate = (
    (df['Loan_Status'] == 'Default').sum()
    / len(df)
) * 100

average_credit_score = df['Credit_Score'].mean()

average_debt_ratio = df['Debt_to_Income_Ratio'].mean()

print("\nKey Findings")

print("1. Overall default rate:", default_rate, "%")
print("2. Average credit score:", average_credit_score)
print("3. Average debt-to-income ratio:", average_debt_ratio)
