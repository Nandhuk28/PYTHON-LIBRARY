import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#topic 1

file = "Ecommerce_Analytics_Intermediate_Project.xlsx"

excel_file = pd.ExcelFile(file)

print("Excel Sheets:")
print(excel_file.sheet_names)

df_orders = pd.read_excel(
    file,
    sheet_name="Raw_Orders"
)

print("\nOrders:")
print(df_orders.head())

print("Rows:", df_orders.shape[0])
print("Columns:", df_orders.shape[1])

df_customers = pd.read_excel(
    file,
    sheet_name="Customers"
)

df_products = pd.read_excel(
    file,
    sheet_name="Products"
)

print("\nCustomers:")
print(df_customers.head())

print("\nProducts:")
print(df_products.head())

#topic 2

df_merged = pd.merge(
    df_orders,
    df_customers,
    on="Customer_ID",
    how="left"
)

print("Task 4")
print(df_merged.head())


df_merged = pd.merge(
    df_merged,
    df_products,
    on="Product_ID",
    how="left"
)

print("\nTask 5")
print(df_merged.head())


print("\nTask 6")
print("Original Order Rows:", len(df_orders))
print("Merged Table Rows:", len(df_merged))

if len(df_orders) == len(df_merged):
    print("No order rows were lost during the merge.")
else:
    print("Order row count has changed.")


print("\nTask 7")
print("Missing Values:")
print(df_merged.isnull().sum())

print("\nMissing Customer Information:")
print(df_merged["Customer_ID"].isnull().sum())

print("Missing Product Information:")
print(df_merged["Product_ID"].isnull().sum())


#topic 3
# Task 8

df_merged["Order_Date"] = pd.to_datetime(
    df_merged["Order_Date"]
)

df_merged["Delivery_Date"] = pd.to_datetime(
    df_merged["Delivery_Date"]
)

print("Task 8")
print(df_merged[
    ["Order_Date", "Delivery_Date"]
].head())

print("\nData Types:")
print(df_merged[
    ["Order_Date", "Delivery_Date"]
].dtypes)


# Task 9

df_merged["Order_Year"] = (
    df_merged["Order_Date"].dt.year
)

df_merged["Order_Month_Number"] = (
    df_merged["Order_Date"].dt.month
)

df_merged["Order_Month_Name"] = (
    df_merged["Order_Date"].dt.month_name()
)

print("\nTask 9")
print(df_merged[
    [
        "Order_Date",
        "Order_Year",
        "Order_Month_Number",
        "Order_Month_Name"
    ]
].head())


# Task 10

df_merged["Order_Day"] = (
    df_merged["Order_Date"].dt.day_name()
)

print("\nTask 10")
print(df_merged[
    ["Order_Date", "Order_Day"]
].head())

#topic 4
# Task 11

df_merged["Delivery_Days"] = (
    df_merged["Delivery_Date"] - df_merged["Order_Date"]
).dt.days

print("Task 11")
print(df_merged[
    ["Order_Date", "Delivery_Date", "Delivery_Days"]
].head())


# Task 12

print("\nTask 12")
print("Empty Delivery Dates:",
      df_merged["Delivery_Date"].isnull().sum())

print("Empty Delivery Days:",
      df_merged["Delivery_Days"].isnull().sum())


# Task 13

average_delivery_days = (
    df_merged["Delivery_Days"].mean()
)

print("\nTask 13")
print("Average Successful Delivery Days:",
      average_delivery_days)


# Task 14

average_by_tier = df_merged.groupby(
    "Membership_Tier"
)["Delivery_Days"].mean()

print("\nTask 14")
print(average_by_tier)


# Task 15

q1_orders = df_merged[
    df_merged["Order_Date"].dt.month.between(1, 3)
]

print("\nTask 15")
print(q1_orders.head())

print("Q1 Orders Count:",
      len(q1_orders))

#topic 5
# Task 16

df_merged["Customer_Name"] = (
    df_merged["Customer_Name"].str.strip().str.upper()
)

df_merged["City"] = (
    df_merged["City"].str.strip().str.upper()
)

print("Task 16")
print(df_merged[
    ["Customer_Name", "City"]
].head())


# Task 17

headphones_keyboard = df_merged[
    df_merged["Product_Name"].str.contains(
        "Headphones|Keyboard",
        case=False,
        na=False
    )
]

print("\nTask 17")
print(headphones_keyboard[
    ["Product_Name"]
].head())


# Task 18

df_merged["Product_ID"] = (
    df_merged["Product_ID"]
    .str.replace("SKU-", "", regex=False)
)

print("\nTask 18")
print(df_merged[
    ["Product_ID"]
].head())


# Task 19

df_merged["Customer_Name_Letters"] = (
    df_merged["Customer_Name"]
    .str.replace(" ", "", regex=False)
    .str.len()
)

print("\nTask 19")
print(df_merged[
    ["Customer_Name", "Customer_Name_Letters"]
].head())


# Task 20

orders_ending_0 = df_merged[
    df_merged["Order_ID"].astype(str).str.endswith("0")
]

print("\nTask 20")
print(orders_ending_0[
    ["Order_ID"]
].head())


# Task 21

smart_count = df_merged["Product_Name"].str.count(
    "Smart",
    flags=2
)

print("\nTask 21")
print(df_merged[
    ["Product_Name"]
].assign(Smart_Count=smart_count).head())

#topic 6

# Task 22

tier_analysis = df_merged.groupby(
    "Membership_Tier"
).agg(
    Total_Sales=("Final_Amount", "sum"),
    Average_Order_Value=("Final_Amount", "mean"),
    Order_Count=("Order_ID", "count")
)

print("Task 22")
print(tier_analysis)


# Task 23

city_category = df_merged.groupby(
    ["City", "Category"]
).agg(
    Total_Sales=("Final_Amount", "sum"),
    Average_Customer_Rating=("Customer_Rating", "mean")
)

print("\nTask 23")
print(city_category)


# Task 24

sales_pivot = pd.pivot_table(
    df_merged,
    index="City",
    columns="Category",
    values="Final_Amount",
    aggfunc="sum",
    fill_value=0
)

print("\nTask 24")
print(sales_pivot)


# Task 25

first_400 = df_merged.iloc[:400]

remaining_rows = df_merged.iloc[400:]

combined_data = pd.concat(
    [first_400, remaining_rows],
    axis=0
)

print("\nTask 25")
print("First 400 Rows:", first_400.shape)
print("Remaining Rows:", remaining_rows.shape)
print("Combined Data:", combined_data.shape)


#topic 7

# Task 26

df_merged["Sales_Rank"] = df_merged.groupby(
    "Category"
)["Final_Amount"].rank(
    method="dense",
    ascending=False
)

print("Task 26")
print(df_merged[
    ["Category", "Order_ID", "Final_Amount", "Sales_Rank"]
].head(10))


# Task 27

customer_spend = df_merged.groupby(
    ["Membership_Tier", "Customer_ID", "Customer_Name"]
)["Final_Amount"].sum().reset_index()

top_3_customers = (
    customer_spend
    .sort_values(
        ["Membership_Tier", "Final_Amount"],
        ascending=[True, False]
    )
    .groupby("Membership_Tier")
    .head(3)
)

print("\nTask 27")
print(top_3_customers)


# Task 28

correlation = df_merged[
    ["Discount_Rate", "Quantity"]
].corr()

print("\nTask 28")
print(correlation)

# topic 8



# Task 29

monthly_tier_sales = df_merged.groupby(
    ["Order_Year", "Order_Month_Number", "Membership_Tier"]
)["Final_Amount"].sum().reset_index()

for tier in monthly_tier_sales["Membership_Tier"].unique():

    data = monthly_tier_sales[
        monthly_tier_sales["Membership_Tier"] == tier
    ]

    plt.plot(
        data["Order_Month_Number"],
        data["Final_Amount"],
        marker="o",
        label=tier
    )

plt.xlabel("Month Number")
plt.ylabel("Total Sales")
plt.title("Monthly Sales by Membership Tier")
plt.legend()
plt.show()


# Task 30

df_merged.boxplot(
    column="Delivery_Days",
    by="Order_Status"
)

plt.xlabel("Order Status")
plt.ylabel("Delivery Days")
plt.title("Delivery Days by Order Status")
plt.suptitle("")
plt.show()


# Task 31

categories = df_merged["Category"].unique()

for category in categories:

    data = df_merged[
        df_merged["Category"] == category
    ]

    plt.scatter(
        data["List_Price"],
        data["Final_Amount"],
        label=category
    )

plt.xlabel("List Price")
plt.ylabel("Final Amount")
plt.title("List Price vs Final Amount")
plt.legend()
plt.show()


# Task 32

corr_data = df_merged[
    [
        "List_Price",
        "Discount_Rate",
        "Quantity",
        "Customer_Rating"
    ]
].corr()

sns.heatmap(
    corr_data,
    annot=True,
    cmap="coolwarm"
)

plt.title("Correlation Heatmap")
plt.show()


# Task 33

monthly_data = df_merged.groupby(
    ["Order_Year", "Order_Month_Number"]
).agg(
    Total_Revenue=("Final_Amount", "sum"),
    Average_Rating=("Customer_Rating", "mean")
).reset_index()

monthly_data["Month"] = (
    monthly_data["Order_Year"].astype(str)
    + "-"
    + monthly_data["Order_Month_Number"].astype(str)
)

fig, ax1 = plt.subplots()

ax1.bar(
    monthly_data["Month"],
    monthly_data["Total_Revenue"]
)

ax1.set_xlabel("Month")
ax1.set_ylabel("Total Revenue")

ax2 = ax1.twinx()

ax2.plot(
    monthly_data["Month"],
    monthly_data["Average_Rating"],
    marker="o"
)

ax2.set_ylabel("Average Rating")

plt.title("Monthly Revenue and Average Rating")
plt.xticks(rotation=45)
plt.show()


# Task 34

city_sales = df_merged.groupby(
    "City"
)["Final_Amount"].sum()

plt.figure()

city_sales.plot(
    kind="bar"
)

plt.xlabel("City")
plt.ylabel("Total Sales")
plt.title("Total Sales by City")
plt.xticks(rotation=45)
plt.show()


plt.figure()

df_merged["Customer_Rating"].plot(
    kind="hist",
    bins=10
)

plt.xlabel("Customer Rating")
plt.ylabel("Frequency")
plt.title("Customer Rating Distribution")
plt.show()


# Task 35

output_file = "Ecommerce_Final_Cleaned_Data.xlsx"

with pd.ExcelWriter(output_file) as writer:

    df_merged.to_excel(
        writer,
        sheet_name="Final_Data",
        index=False
    )

    tier_analysis.to_excel(
        writer,
        sheet_name="Tier_Analysis"
    )

    sales_pivot.to_excel(
        writer,
        sheet_name="Sales_Pivot"
    )

    city_category.to_excel(
        writer,
        sheet_name="City_Category"
    )

df_merged.to_csv(
    "Ecommerce_Final_Cleaned_Data.csv",
    index=False
)

print("Excel file saved:", output_file)
print("CSV file saved: Ecommerce_Final_Cleaned_Data.csv")

